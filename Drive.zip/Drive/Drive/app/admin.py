from django.contrib import admin
from .models import *


class SocialInfoModel(admin.ModelAdmin):
    list_display = ['id', 'linkedin', 'github','twitter', 'instagram', 'facebook', 'whatsapp','googleplus',  'telegram',    'flicker']
    list_editable  = ['linkedin', 'github','twitter', 'instagram', 'facebook', 'whatsapp','googleplus',  'telegram',    'flicker']
admin.site.register(SocialInfo,SocialInfoModel)



