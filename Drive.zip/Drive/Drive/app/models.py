"""
Definition of models.
"""

from django.db import models


class SocialInfo(models.Model):
    facebook = models.URLField(max_length=5000, blank=True)
    twitter = models.URLField(max_length=5000, blank=True)
    googleplus = models.URLField(max_length=5000, blank=True)
    instagram = models.URLField(max_length=5000, blank=True)
    flicker = models.URLField(max_length=5000, blank=True)
    telegram = models.URLField(max_length=5000, blank=True)
    whatsapp = models.URLField(max_length=5000, blank=True)
    github = models.URLField(max_length=5000, blank=True)
    linkedin = models.URLField(max_length=5000, blank=True)


