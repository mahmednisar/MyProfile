from django.urls import path
from app import forms, views

app_name='app'

urlpatterns = [
    path('', views.home, name='home'),
]
