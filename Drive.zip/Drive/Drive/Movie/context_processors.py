from Movie.models import Genre,Movie
from app.models import SocialInfo
from Books.models import Book, Tutorial, Category as BookCat
from Softwares.models import  Category as SoftCat

def add_variable_to_context(request):
    genre = Genre.objects.all().order_by('genre')
    hollywood= Movie.objects.all().filter(type='H').count()
    bollywood= Movie.objects.all().filter(type='B').count()
    other= Movie.objects.all().filter(type='S').count()
    series = Movie.objects.all().filter(type='W').count()
    dubbed = Movie.objects.all().filter(type='H').count()
    social = SocialInfo.objects.all()
    catlst = BookCat.objects.all()
    softcatlst = SoftCat.objects.all()
    return {'genrelst': genre, 'lhollywood':hollywood, 'lbollywood':bollywood, 'lother':other, 'lseries':series, 'dubbed':dubbed, 'socialinfo':social, 'catlst':catlst, 'softcat': softcatlst}
