from django_summernote.widgets import SummernoteWidget
from django.contrib import admin
from .models import *


class MovieModel(admin.ModelAdmin):
    fieldsets = [
        ("ID/ Name", {'fields': ["movieid", "title"]}),
        ("Type", {'fields': ["type","dubbed"]}),
        ("Related Details", {'fields': ["release","length","rate","poster","image","genre",]}),
        ("Description and URL ", {"fields": ["description","description2","trailer","download_Link"]})
    ]
    formfield_overrides = {
         models.TextField: {'widget': SummernoteWidget()},
      }

admin.site.register(Movie,MovieModel)

class GenreAdmin(admin.ModelAdmin):
    list_display = ('genre', 'slug')
    list_editable = ['slug']
admin.site.register(Genre, GenreAdmin)

