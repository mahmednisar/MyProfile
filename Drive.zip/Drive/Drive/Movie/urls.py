from django.urls import path
from Movie import views

app_name='movie'

urlpatterns = [
    path('', views.home, name='home'),
    path('bollywood/', views.bollywood, name='bollywood'),
    path('hollywood/', views.hollywood, name='hollywood'),
    path('dubbed/', views.dubbed, name='dubbed'),
    path('series/', views.series, name='series'),
    path('other/', views.other, name='other'),
    path('movies/', views.getdetail, name='getdetail'),
    path('category/<str:slug>', views.category, name='category'),
    path('detail/<str:id>', views.viewdetal, name='viewdetail'),
]
