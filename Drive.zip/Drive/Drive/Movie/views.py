"""
Definition of views.
"""

from datetime import datetime
from django.shortcuts import render
from django.http import HttpRequest
from Movie.models import * 
from django.db.models import F
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger


def home(request):
    popular= Movie.objects.all().order_by('-weight')[:10]
    latest= Movie.objects.all().order_by('-release')[:10]
    params ={'title':'Movies - Home ',  'popular':popular, 'latest':latest  }
    return render(request,'Movie/index.html', params)

def getdetail(request):
    movie= Movie.objects.all().order_by('-release', '-weight')
    page = request.GET.get('page',1)
    paginator = Paginator(movie, 12)
    try:
        page_obj = paginator.page(page)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)
    params ={'title':'All Movies',  'movie':page_obj}
    return render(request,'Movie/list.html', params)

def dubbed(request):
    movie= Movie.objects.filter(dubbed=1)
    page = request.GET.get('page',1)
    paginator = Paginator(movie, 12)
    try:
        page_obj = paginator.page(page)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)
    params ={'title':'Dubbed Movies',  'movie':page_obj}
    return render(request,'Movie/list.html', params)

def bollywood(request):
    movie= Movie.objects.filter(type='B')
    page = request.GET.get('page',1)
    paginator = Paginator(movie, 12)
    try:
        page_obj = paginator.page(page)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)
    params ={'title':'Bollywood Movies',  'movie':page_obj }
    return render(request,'Movie/list.html', params)

def hollywood(request):
    movie= Movie.objects.filter(type='H')
    page = request.GET.get('page',1)
    paginator = Paginator(movie, 12)
    try:
        page_obj = paginator.page(page)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)
    params ={'title':'Hollywood Movies',  'movie':page_obj  }
    return render(request,'Movie/list.html', params)

def series(request):
    movie= Movie.objects.filter(type='W')
    page = request.GET.get('page',1)
    paginator = Paginator(movie, 12)
    try:
        page_obj = paginator.page(page)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)
    params ={'title':'Series',  'movie':page_obj   }
    return render(request,'Movie/list.html', params)

def other(request):
    movie= Movie.objects.filter(type='S')
    page = request.GET.get('page',1)
    paginator = Paginator(movie, 12)
    try:
        page_obj = paginator.page(page)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)
    params ={'title':'Other Movies',  'movie':page_obj   }
    return render(request,'Movie/list.html', params)

def category(request, slug):
#    gen= Genre.objects.filter(slug=genre)
    movie= Movie.objects.filter(genre__slug__startswith=slug)
    page = request.GET.get('page',1)
    paginator = Paginator(movie, 12)
    try:
        page_obj = paginator.page(page)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)
    genre= Genre.objects.filter(slug=slug)
    title=''
    for g in genre:
        title= g.genre
    params ={'title':'Movies & Series Category - '+ title,  'movie':page_obj   }
    return render(request,'Movie/list.html', params)

def viewdetal(request, id):
    movie= Movie.objects.filter(movieid=id)
    Movie.objects.filter(movieid=id).update(weight=F('weight') +1)
    movielst= Movie.objects.all().order_by('-rate')[:5]
    hollywood= Movie.objects.all().filter(type='H').count()
    bollywood= Movie.objects.all().filter(type='B').count()
    other= Movie.objects.all().filter(type='S').count()
    series = Movie.objects.all().filter(type='W').count()
    dubbed = Movie.objects.all().filter(type='H').count()
    genre= Genre.objects.all().order_by('genre')
    params ={'title':'Movies', 'movie':movie, 'movielst':movielst, 'genre':genre, 'hollywood': hollywood, 'bollywood': bollywood, 'other': other, 'series':series, 'dubbed':dubbed  }
    return render(request,'Movie/view.html', params)
