from django.db import models
import datetime
from PIL import Image


TYPE_CHOICES = (
   ('H', 'Hollywood'),
   ('B', 'Bolywood'),
   ('S', 'South Indian'),
   ('W', 'Series'),
)


class Movie(models.Model):
    movieid = models.CharField(max_length=20, primary_key=True)
    title = models.CharField(max_length=1000, blank=True)
    type = models.CharField(choices=TYPE_CHOICES, max_length=128)
    dubbed  =  models.BooleanField() 
    release = models.DateField( default=datetime.date.today)
    length = models.CharField(max_length=10, blank=True)
    rate = models.DecimalField(default=0,max_digits=200, decimal_places=1, blank=True)
    poster = models.URLField(default='', blank=True)
    genre = models.ManyToManyField('Genre', default='', blank=True)
    description = models.TextField(max_length=4000, blank=True)
    description2 = models.TextField(max_length=4000, blank=True)
    trailer = models.URLField(default='', blank=True)
    download_Link = models.URLField(default='', blank=True)
    image = models.ImageField(upload_to='Movies/', blank=True)
    weight = models.IntegerField(default=0, blank=True)
    def __str__(self):
        return (str(self.movieid))+' | '+self.title


class Genre(models.Model):
    genre = models.CharField(max_length=100, primary_key=True)
    slug = models.SlugField(max_length = 200, db_index=True)
    
    def __str__(self):
        return self.genre 

