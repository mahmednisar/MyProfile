from django.urls import path,include
from django.conf.urls import url
from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('superuser/', admin.site.urls),
    path('',include('app.urls'), name='app'),
    path('movie/',include('Movie.urls'), name='movie'),
    path('books/',include('Books.urls'), name='books'),
    path('softwares/',include('Softwares.urls'), name='softwares'),
    path('summernote/', include('django_summernote.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)