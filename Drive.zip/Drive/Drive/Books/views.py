"""
Definition of views.
"""
from django.shortcuts import render, redirect
from datetime import datetime
from django.shortcuts import render
from django.http import HttpRequest
from Books.models import * 
from django.db.models import F
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
import math
import operator
import random


def home(request):
    books= Book.objects.all().order_by('?')[:10]
    tutorials= Tutorial.objects.all().order_by('?')[:10]
    params ={'title':'Books & Tutoials - Home ',  'books':books,'tutorials':tutorials,}
    return render(request,'Books/index.html', params)


def getlist(request,model, slug):
    lst= model.objects.filter(category__slug__startswith=slug)
    page = request.GET.get('page',1)
    paginator = Paginator(lst, 12)
    try:
        page_obj = paginator.page(page)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)
    category= Category.objects.filter(slug=slug)
    title=''
    for c in category:
        title= c.category
    mod= model.get_name()
    params ={'title':mod+' Category - '+ title,'model':mod,  'page_obj':page_obj   }
    return render(request,'Books/list.html', params)

def viewdetal(request, model, id):
    if model.get_name() == 'Book':
        detail= model.objects.filter(bookid=id)
    else:
         detail= model.objects.filter(tutorialid=id)
    lst= model.objects.all().order_by('?')[:5]
    category= Category.objects.all().order_by('category')
    mod= model.get_name()
    params ={'title':'View '+(str(mod)), 'model':(str(mod)), 'list':lst, 'detail':detail, 'category':category, }
    return render(request,'Books/view.html', params)
