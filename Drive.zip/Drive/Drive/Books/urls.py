from django.urls import path
from Books import views
from Books import models

app_name='books'

urlpatterns = [
    path('', views.home, name='home'),
    path('tutorial/<str:slug>', views.getlist, {'model': models.Tutorial}, name='tutorialcat'),
    path('book/<str:slug>', views.getlist, {'model': models.Book}, name='bookcat'),
    path('tutorialdetail/<str:id>', views.viewdetal, {'model': models.Tutorial}, name='tutorialview'),
    path('bookdetail/<str:id>', views.viewdetal, {'model': models.Book}, name='bookview'),
]
