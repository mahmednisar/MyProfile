from django_summernote.widgets import SummernoteWidget
from django.contrib import admin
from .models import *


class BookModel(admin.ModelAdmin):
    list_display = ('bookid', 'title', 'Publisher', 'writer', 'published')
    list_filter = ['category', ]
    fieldsets = [
        ("ID/ Name", {'fields': ["bookid", "title"]}),
        ("Writer/Publisher", {'fields': ["Publisher","writer","published"]}),
        ("Related Details", {'fields': ["rate","poster","image","category",]}),
        ("Description and URL ", {"fields": ["description","description2","download_Link"]})
    ]
    formfield_overrides = {
         models.TextField: {'widget': SummernoteWidget()},
      }

admin.site.register(Book,BookModel)


class TutorialModel(admin.ModelAdmin):
    list_display = ('tutorialid', 'title', 'Publisher', 'writer',)
    list_filter = ['category', ]
    fieldsets = [
        ("ID/ Name", {'fields': ["tutorialid", "title"]}),
        ("Writer/Publisher", {'fields': ["Publisher","writer",]}),
        ("Related Details", {'fields': ["rate","poster","image","category",]}),
        ("Description and URL ", {"fields": ["description","description2","download_Link"]})
    ]
    formfield_overrides = {
         models.TextField: {'widget': SummernoteWidget()},
      }

admin.site.register(Tutorial,TutorialModel)

class CategoryAdmin(admin.ModelAdmin):
    list_display = ('category', 'slug')
    list_editable = ['slug']
admin.site.register(Category, CategoryAdmin)

