from django.db import models
import datetime
from PIL import Image



class Book(models.Model):
    bookid= models.CharField(max_length=100, primary_key=True)
    title = models.CharField(max_length=1000, blank=True)
    Publisher = models.CharField(max_length=1000, blank=True)
    writer = models.CharField(max_length=1000, blank=True)
    published = models.DateField( default=datetime.date.today)
    rate = models.DecimalField(default=0,max_digits=200, decimal_places=1, blank=True)
    poster = models.URLField(default='', blank=True)
    category = models.ManyToManyField('Category', default='', blank=True)
    description = models.TextField(max_length=4000, blank=True)
    description2 = models.TextField(max_length=4000, blank=True)
    download_Link = models.URLField(default='', blank=True)
    image = models.ImageField(upload_to='Books/', blank=True)
    def __str__(self):
        return (str(self.bookid))+' | '+self.title
    @staticmethod
    def get_name():
        return 'Book'

class Tutorial(models.Model):
    tutorialid= models.CharField(max_length=100, primary_key=True)
    title = models.CharField(max_length=1000, blank=True)
    Publisher = models.CharField(max_length=1000, blank=True)
    writer = models.CharField(max_length=1000, blank=True)
    rate = models.DecimalField(default=0,max_digits=200, decimal_places=1, blank=True)
    poster = models.URLField(default='', blank=True)
    category = models.ManyToManyField('Category', default='', blank=True)
    description = models.TextField(max_length=4000, blank=True)
    description2 = models.TextField(max_length=4000, blank=True)
    download_Link = models.URLField(default='', blank=True)
    image = models.ImageField(upload_to='Tutorial/', blank=True)
    def __str__(self):
        return (str(self.bookid))+' | '+self.title

    @staticmethod
    def get_name():
        return 'Tutorial'

class Category(models.Model):
    category = models.CharField(max_length=100, primary_key=True)
    slug = models.SlugField(max_length = 200, db_index=True)
    
    def __str__(self):
        return self.category 

