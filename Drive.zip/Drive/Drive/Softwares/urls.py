from django.urls import path
from Softwares import views

app_name='softwares'

urlpatterns = [
    path('', views.home, name='home'),
    path('category/<str:slug>', views.category, name='category'),
    path('detail/<str:id>', views.viewdetal, name='viewdetail'),
]
