"""
Definition of views.
"""

from datetime import datetime
from django.shortcuts import render
from django.http import HttpRequest
from Softwares.models import * 
from django.db.models import F
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger


def home(request):
    popular= Software.objects.all().order_by('-weight')[:20]
    cat= Category.objects.all().order_by('category')
    params ={'title':'Softwares - Home ',  'popular':popular, 'category':cat, }
    return render(request,'Softwares/index.html', params)

def category(request, slug):
    soft= Software.objects.filter(category__slug__startswith=slug).order_by('-title')
    page = request.GET.get('page',1)
    paginator = Paginator(soft, 12)
    try:
        page_obj = paginator.page(page)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)
    category= Category.objects.filter(slug=slug)
    title=''
    for c in category:
        title= c.category
    params ={'title':'Software Category - '+ title,  'page_obj':page_obj   }
    return render(request,'Softwares/list.html', params)

def viewdetal(request, id):
    soft= Software.objects.filter(id=id)
    Software.objects.filter(id=id).update(weight=F('weight') +1)
    softlist= Software.objects.all().order_by('-weight')[:5]
    cat= Category.objects.all().order_by('category')
    params ={'title':'Softwares', 'soft':soft, 'softlst':softlist, 'cat':cat,   }
    return render(request,'Softwares/view.html', params)
