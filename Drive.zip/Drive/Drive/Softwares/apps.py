from django.apps import AppConfig


class SoftwaresConfig(AppConfig):
    name = 'Softwares'
