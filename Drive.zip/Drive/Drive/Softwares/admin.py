from django_summernote.widgets import SummernoteWidget
from django.contrib import admin
from .models import *


class SoftwareModel(admin.ModelAdmin):
    fieldsets = [
        (" Name", {'fields': [ "title"]}),
        ("Related Details", {'fields': ["poster","image","category",]}),
        ("Description and URL ", {"fields": ["description","description2","download_Link"]})
    ]
    formfield_overrides = {
         models.TextField: {'widget': SummernoteWidget()},
      }

admin.site.register(Software,SoftwareModel)

class CategoryAdmin(admin.ModelAdmin):
    list_display = ('category', 'slug')
    list_editable = ['slug']
admin.site.register(Category, CategoryAdmin)

